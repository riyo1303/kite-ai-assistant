const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function handleTask(input) {
  const text = input.toLowerCase();

  if (text.includes("halo")) return "Halo juga! 👋";
  if (text.includes("nama")) return "Saya AI Assistant Riyo 🤖";
  if (text.includes("apa kabar")) return "Saya baik 🚀";
  if (text.includes("help")) return "Coba: halo, nama, apa kabar";

  return "Aku belum ngerti 😅";
}

function start() {
  console.log("AI aktif...");
  rl.question("Kamu: ", (ans) => {
    console.log("AI:", handleTask(ans));
    start();
  });
}

start();
