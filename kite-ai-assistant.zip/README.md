# 🤖 Kite AI Assistant

Simple AI assistant project for GitHub practice.

## Run
node scripts/task_handler.js
